<p>Raspberry PI Pico 2 Clone with built in 4x4 Neopixel RGB Matrix and OLED Port supporting any size monochrome or color, but small 0.91" 128x32 pixel display fits nicely.</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。