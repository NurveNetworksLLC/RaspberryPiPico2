<p>Simple USB to 3.3V Power Supply with LEDs and terminal block output. This project is derived from my new Raspberry Pi Pico 2 design course on udemy as an example of a small warm up PCB project.</p>
<p> </p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。